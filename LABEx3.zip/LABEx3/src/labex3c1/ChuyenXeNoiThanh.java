package labex3c1;

public class ChuyenXeNoiThanh extends ChuyenXe{
    private int soTuyen;
    private float soKmDiDuoc;

    public ChuyenXeNoiThanh() {
    }

    public ChuyenXeNoiThanh(int soTuyen, float soKmDiDuoc, int maSoChuyen, String hoTenTaiXe, int soXe, double doanhThu) {
        super(maSoChuyen, hoTenTaiXe, soXe, doanhThu);
        this.soTuyen = soTuyen;
        this.soKmDiDuoc = soKmDiDuoc;
    }

    public int getSoTuyen() {
        return soTuyen;
    }

    public void setSoTuyen(int soTuyen) {
        this.soTuyen = soTuyen;
    }

    public float getSoKmDiDuoc() {
        return soKmDiDuoc;
    }

    public void setSoKmDiDuoc(float soKmDiDuoc) {
        this.soKmDiDuoc = soKmDiDuoc;
    }

    @Override
    public String toString() {
        return "ChuyenXeNoiThanh{" + "soTuyen=" + soTuyen + ", soKmDiDuoc=" + soKmDiDuoc + '}';
    }
}
