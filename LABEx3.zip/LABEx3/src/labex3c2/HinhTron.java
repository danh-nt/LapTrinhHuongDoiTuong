package labex3c2;

public class HinhTron extends Hinh {
    private float cd;
    private float cr;

    public HinhTron() {
    }

    public HinhTron(float cd, float cr) {
        this.cd = cd;
        this.cr = cr;
    }

    @Override
    public double dienTich() {
        return (cd * cr);
    }
    
    @Override
    public String toString() {
        return "HinhTron{" + "cd=" + cd + ", cr=" + cr + '}';
    }
}
