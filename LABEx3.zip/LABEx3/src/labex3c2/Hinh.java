package labex3c2;

public class Hinh {
    private double dienTich;
    
    public double dienTich() {
        return dienTich;
    }  
}
