package labex3c2;

public class HinhChuNhat extends Hinh {
    private float r;

    public HinhChuNhat() {
    }

    public HinhChuNhat(float r) {
        this.r = r;
    }
    
    @Override
    public double dienTich() {
        return (r * r * 3.14);
    }
    
    @Override
    public String toString() {
        return "HinhChuNhat{" + "r=" + r + '}';
    }
    
    
}
