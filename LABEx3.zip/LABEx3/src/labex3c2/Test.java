package labex3c2;

public class Test {
    public static void main(String[] args) {
        HinhTron nhapHinhTron = new HinhTron();
        nhapHinhTron.dienTich();
        HinhChuNhat nhapHinhChuNhat = new HinhChuNhat();
        nhapHinhChuNhat.dienTich();
    }
}
