package bai3;

public class Circle extends Shape {
    public double radius = 1;
    public double pi = 3.14;

    public Circle() {
    }

    public Circle(String color, boolean filled, double radius) {
        super(color, filled);
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    @Override
    public String toString() {
        return "circle{" + "radius=" + radius + '}';
    }
    
    public double getArea() {
        return getArea();
    }
    public double getPerimeter() {
        return getPerimeter();
    }
}
