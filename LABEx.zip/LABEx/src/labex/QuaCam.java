package labex;

public class QuaCam extends HoaQua {

    public QuaCam(String nguongoc, int giaban, long soluong, int ngaynhap, String mausac) {
        super(nguongoc, giaban, soluong, ngaynhap, mausac);
    }
}
