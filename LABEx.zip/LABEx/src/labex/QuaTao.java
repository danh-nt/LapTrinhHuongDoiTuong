package labex;

public class QuaTao extends HoaQua {
    
    public QuaTao(String nguongoc, int giaban, long soluong, int ngaynhap, String mausac){
        super(nguongoc, giaban, soluong, ngaynhap, mausac);   
    }
}
