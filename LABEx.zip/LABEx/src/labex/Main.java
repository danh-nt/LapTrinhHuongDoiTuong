package labex;

public class Main {
    public static void main(String[] args) {
        QuaCam CamSanh = new QuaCam("vietnam", 30, 100, 20, "xanh");
    }
}
