package lab2;

import java.util.Scanner;

public class TinhTienDien {
    public static void main(String[] args) {
    /* Bài 3: Viết chương trình nhập vào số điện sử dụng của tháng và tính tiền 
    điện theo phương pháp lũy tiến */
    Scanner scanner = new Scanner(System.in);
        
    System.out.println("Nhap so dien dung thang nay: ");
    int SoDien = scanner.nextInt();

    if (SoDien == 0 || SoDien < 50) {
        int tien;
        tien = SoDien*1000;
        System.out.println("So tien dung thang nay la: " + tien);
    } else {
        int tien;
        tien = 50*1000 + (SoDien - 50)*1200;
        System.out.println("So tien dung vuot muc thang nay la: " + tien);
    }
    }
}
