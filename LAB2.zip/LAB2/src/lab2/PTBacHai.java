package lab2;

import java.util.Scanner;

public class PTBacHai {
    /* Bài 2: Viết chương trình cho phép giải phương trình bậc hai trong đó các 
    hệ số a, b và c nhập từ bàn phím */
    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    
    System.out.println("Nhap a:");
    float a = scanner.nextFloat();
    System.out.println("Nhap b:");
    float b = scanner.nextFloat();
    System.out.println("Nhap c:");
    float c = scanner.nextFloat();
    float x = -b/a;
        
        //Nếu a = 0, giải phương trình bậc nhất
        if (a==0) {
            if (b==0) {
                System.out.println("Phuong trinh vo so nghiem!");
            } else {
                System.out.println("Phuong trinh vo nghiem!");
            }
        } else {
            System.out.println("Phuong trinh co nghiem x = " + x);
        }
        
        //Nếu a # 0, giải phương trình bậc hai
        if (a!=0) {
            float D = (b*b)-(4*a*c);
            if (D < 0) {
                System.out.println("Phuong trinh vo nghiem!");
            } else {
                if (D==0) {
                    x = -b/(2*a);
                    System.out.println("Phuong trinh co nghiem kep x = " + x);
                } else {
                    double x1 = (-b + Math.sqrt(D))/2*a;
                    double x2 = (-b - Math.sqrt(D))/2*a;
                    System.out.println("Phuong trinh co hai nghiem phan biet:");
                    System.out.println("Nghiem x1 = " + x1);
                    System.out.println("Nghiem x2 = " + x2);
                }
            }  
        }
    }
}

