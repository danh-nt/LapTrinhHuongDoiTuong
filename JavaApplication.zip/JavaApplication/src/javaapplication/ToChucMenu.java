package javaapplication;

import java.util.Scanner;

public class ToChucMenu {
    /* Bài 4: Viết chương trình tổ chức một menu gồm ba chức năng để gọi ba bài trên và một chức
năng để thoát khỏi ứng dụng. */
    
    //Hàm phương trình bậc nhất
    static void PTBacNhat() {
    Scanner scanner = new Scanner(System.in);
    
    System.out.println("Nhap a:");
    float a = scanner.nextFloat();
    System.out.println("Nhap b:");
    float b = scanner.nextFloat();
    float x;
    x = -b/a;
    
        if (a==0) {
            if (b==0) {
                System.out.println("Phuong trinh vo so nghiem!");
            } else {
                System.out.println("Phuong trinh vo nghiem!");
            }
        } else {
            System.out.println("Phuong trinh co nghiem x = " + x);
        }
    }     
    
    //Hàm phương trình bậc hai
    static void PTBacHai() {
    Scanner scanner = new Scanner(System.in);
    
    System.out.println("Nhap a:");
    float a = scanner.nextFloat();
    System.out.println("Nhap b:");
    float b = scanner.nextFloat();
    System.out.println("Nhap c:");
    float c = scanner.nextFloat();
    float x = -b/a;
        
        //Nếu a = 0, giải phương trình bậc nhất
        if (a==0) {
            if (b==0) {
                System.out.println("Phuong trinh vo so nghiem!");
            } else {
                System.out.println("Phuong trinh vo nghiem!");
            }
        } else {
            System.out.println("Phuong trinh co nghiem x = " + x);
        }
        
        //Nếu a # 0, giải phương trình bậc hai
        if (a!=0) {
            float D = (b*b)-(4*a*c);
            if (D < 0) {
                System.out.println("Phuong trinh vo nghiem!");
            } else {
                if (D==0) {
                    x = -b/(2*a);
                    System.out.println("Phuong trinh co nghiem kep x = " + x);
                } else {
                    double x1 = (-b + Math.sqrt(D))/2*a;
                    double x2 = (-b - Math.sqrt(D))/2*a;
                    System.out.println("Phuong trinh co hai nghiem phan biet:");
                    System.out.println("Nghiem x1 = " + x1);
                    System.out.println("Nghiem x2 = " + x2);
                }
            }  
        }
    }
    
    //Hàm tính tiền điện
    static void TinhTienDien() {
    Scanner scanner = new Scanner(System.in);
        
    System.out.println("Nhap so tien dung thang nay: ");
    int SoDien = scanner.nextInt();

    if (SoDien == 0 || SoDien < 50) {
        int tien;
        tien = SoDien*1000;
        System.out.println("So tien dung thang nay la: " + tien);
    } else {
        int tien;
        tien = 50*1000 + (SoDien - 50)*1200;
        System.out.println("So tien dung vuot muc thang nay la: " + tien);
    }
    }
    
    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.println("+---------------------------------------------------+");
    System.out.println("1. Giai phuong trinh bac nhat");
    System.out.println("2. Giai phuong trinh bac hai");
    System.out.println("3. Tinh tien dien");
    System.out.println("4. Ket thuc");
    System.out.println("+---------------------------------------------------+");
    System.out.print("Chon chuc nang: ");
    int so = scanner.nextInt();
    switch (so) {
        case 1:
           PTBacNhat();
           break;
        case 2:
           PTBacHai();
           break;
        case 3:
            TinhTienDien();
        case 4:
            System.exit(0);
    }
    }
}
