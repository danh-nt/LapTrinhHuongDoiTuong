package javaapplication;

import java.util.Scanner;

public class PTBacNhat {
    /* Viết chương trình cho phép giải phương trình bậc nhất trong đó các hệ số a và b
nhập từ bàn phím */
    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    
    System.out.println("Nhap a:");
    float a = scanner.nextFloat();
    System.out.println("Nhap b:");
    float b = scanner.nextFloat();
    float x;
    x = -b/a;
    
        if (a==0) {
            if (b==0) {
                System.out.println("Phuong trinh vo so nghiem!");
            } else {
                System.out.println("Phuong trinh vo nghiem!");
            }
        } else {
            System.out.println("Phuong trinh co nghiem x = " + x);
        }
    } 
}

