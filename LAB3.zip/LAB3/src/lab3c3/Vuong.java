package lab3c3;

public class Vuong {
    /* Viết khai báo một gói chứa hai lớp: Lớp hình vuông, lớp hình tròn. Viết 
    khai báo lớp hình vuông, lớp hình tròn cùng các thuộc tính thích hợp, các 
    phương thức get/set thích hợp. */
    
    private int canh;
    private int chuvi = canh + canh;
    private int dientich = canh * canh;
    
    public Vuong(int canh, int chuvi, int dientich) {
        this.canh = canh;
        this.chuvi = chuvi;
        this.dientich = dientich;
    }

    public int getCanh() {
        return canh;
    }

    public void setCanh(int canh) {
        this.canh = canh;
    }

    public int getChuvi() {
        return chuvi;
    }

    public void setChuvi(int chuvi) {
        this.chuvi = chuvi;
    }

    public int getDientich() {
        return dientich;
    }

    public void setDientich(int dientich) {
        this.dientich = dientich;
    }

    @Override
    public String toString() {
        return "Vuong{" + "canh=" + canh + ", chuvi=" + chuvi + ", dientich=" + dientich + '}';
    }
}
