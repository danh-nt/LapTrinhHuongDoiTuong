package lab3c3;

public class Tron {
    /* Viết khai báo một gói chứa hai lớp: Lớp hình vuông, lớp hình tròn. Viết 
    khai báo lớp hình vuông, lớp hình tròn cùng các thuộc tính thích hợp, các 
    phương thức get/set thích hợp. */
    
    private float r;
    private float d;
    private double chuvi = d * Math.PI;
    private double dientich = Math.PI * r * r;
    
    public Tron(float r, float d, float chuvi, float dientich) {
        this.r = r;
        this.d = d;
        this.chuvi = chuvi;
        this.dientich = dientich;
    }

    public float getR() {
        return r;
    }

    public void setR(float r) {
        this.r = r;
    }

    public float getD() {
        return d;
    }

    public void setD(float d) {
        this.d = d;
    }

    public double getChuvi() {
        return chuvi;
    }

    public void setChuvi(double chuvi) {
        this.chuvi = chuvi;
    }

    public double getDientich() {
        return dientich;
    }

    public void setDientich(double dientich) {
        this.dientich = dientich;
    }

    @Override
    public String toString() {
        return "Tron{" + "r=" + r + ", d=" + d + ", chuvi=" + chuvi + ", dientich=" + dientich + '}';
    }
}
