package lab3c1;

public class Fraction {
    // Viết code định nghĩa lớp Fraction định nghĩa một phân số với hai thành phần tử số và mẫu số.
    private int num;
    private int den;
    
    public Fraction(int num, int den) {
        this.num = num;
        this.den = den;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public int getDen() {
        return den;
    }

    public void setDen(int den) {
        this.den = den;
    }
    
    
}
