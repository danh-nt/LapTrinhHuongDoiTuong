package lab3c1;

public class Triangle {
    // Viết code định nghĩa lớp Triangle định nghĩa một tam giác với chiều dài cạnh đáy và chiều cao.
    private float width = 0.0f;
    private float heigth = 0.0f;
    
    public Triangle(float width, float heigth) {
        this.width = width;
        this.heigth = heigth;
    }

    public float getWidth() {
        return width;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public float getHeigth() {
        return heigth;
    }

    public void setHeigth(float heigth) {
        this.heigth = heigth;
    }

    @Override
    public String toString() {
        return "Triangle{" + "width=" + width + ", heigth=" + heigth + '}';
    }
}
