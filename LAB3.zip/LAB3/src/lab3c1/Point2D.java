package lab3c1;

public class Point2D {
    // Viết code định nghĩa lớp Point 2D định nghĩa đối tượng điểm trong mặt phẳng hai chiều.
    private float x = 0.0f;
    private float y = 0.0f;
    
    public Point2D(float x, float y) {
        this.x = x;
        this.y = y;
    }
    public float getX() {
        return this.x;
    }
    
    public float getY() {
        return this.y;
    }
}